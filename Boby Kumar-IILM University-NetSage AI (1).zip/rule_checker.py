import ipaddress
import re

def check_case(text: str):
    """Deterministic checks for common Cisco/Packet Tracer mistakes."""
    t = text.lower()
    findings = []

    if "169.254." in t and ("dhcp" in t or "ip address" in t):
        findings.append("Possible DHCP failure: host has an APIPA address.")

    if "administratively down" in t or "shutdown" in t:
        findings.append("Interface may be administratively shut down.")

    if "does not list vlan" in t or "not allowed" in t:
        findings.append("Possible VLAN/trunk allowance problem.")

    if "no route" in t or "no matching route" in t or "default route is missing" in t:
        findings.append("Possible missing route/default route.")

    if "helper-address" in t and ("no" in t or "missing" in t):
        findings.append("Possible missing DHCP relay (ip helper-address).")

    if "deny tcp" in t or "deny ip" in t:
        findings.append("ACL may be blocking the required traffic.")

    if "nat translations empty" in t:
        findings.append("NAT may not be matching/creating translations.")

    if "same ip" in t or "duplicate ip" in t or "conflicting mac" in t:
        findings.append("Possible duplicate IP address.")

    if "gateway" in t and "mismatch" in t:
        findings.append("Possible default gateway/subnet mismatch.")

    return findings

if __name__ == "__main__":
    sample = """PC has IP but cannot reach server. show ip route has no route to
    192.168.40.0/24. Gateway ping works."""
    print("NetSage Rule Checker")
    for item in check_case(sample):
        print("[CHECK]", item)
