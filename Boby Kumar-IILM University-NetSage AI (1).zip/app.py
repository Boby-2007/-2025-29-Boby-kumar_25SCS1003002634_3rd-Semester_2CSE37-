import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
from rule_checker import check_case
from ai_diagnosis import local_diagnosis

st.set_page_config(
    page_title="NetSage AI",
    page_icon="🌐",
    layout="wide"
)

cases = pd.read_csv("data/cases.csv")
reviews = pd.read_csv("review_log.csv")

st.title("🌐 NetSage AI")
st.caption(
    "AI-assisted Cisco / Packet Tracer troubleshooting with mandatory human review"
)

tab1, tab2, tab3 = st.tabs(
    ["🔧 Troubleshooter", "📊 Dashboard", "🧠 Responsible AI"]
)

with tab1:
    st.subheader("Troubleshooting Case")

    selected = st.selectbox(
        "Select case",
        cases["case_id"]
    )

    row = cases[cases.case_id == selected].iloc[0]

    c1, c2 = st.columns(2)

    with c1:
        st.markdown("### Symptom")
        st.info(row["symptom"])

        st.markdown("### Topology / Show Evidence")
        st.code(row["evidence"])

    with c2:
        st.markdown("### Expected Fault")
        st.write(row["expected_fault"])

        st.write(
            f"**OSI:** {row['osi_layer']}  | "
            f"**Concept:** {row['concept']}  | "
            f"**Severity:** {row['severity']}"
        )

    text = row["symptom"] + " " + row["evidence"]

    # -----------------------------
    # Rule Checker
    # -----------------------------
    if st.button("Run Rule Checker"):
        findings = check_case(text)

        if findings:
            for x in findings:
                st.success(x)
        else:
            st.warning(
                "No deterministic rule matched. Collect more evidence."
            )

    # -----------------------------
    # AI Diagnosis Button
    # -----------------------------
    if st.button("Run NetSage AI Diagnosis"):
        result = local_diagnosis(
            row["symptom"],
            row["evidence"]
        )

        st.session_state["result"] = result

    # -----------------------------
    # AI Diagnosis Display
    # -----------------------------
    if "result" in st.session_state:

        r = st.session_state["result"]

        st.markdown("## AI Diagnosis")

        st.write(
            "**Root Cause:**",
            r["root_cause"]
        )

        st.write(
            "**Confidence:**",
            r["confidence"]
        )

        st.write(
            "**OSI Layer:**",
            r["osi_layer"]
        )

        st.write(
            "**Evidence:**",
            r["evidence"]
        )

        st.write("**Next Command:**")
        st.code(r["next_command"])

        st.write("**Fix Steps:**")

        for step in r["fix_steps"]:
            st.write("•", step)

        st.warning(
            "⚠️ HUMAN REVIEW REQUIRED — "
            "do not apply a configuration change until reviewed."
        )

        status = st.radio(
            "Human decision",
            ["Accepted", "Edited", "Rejected"],
            horizontal=True
        )

        reviewer_note = st.text_area(
            "Reviewer note",
            placeholder=(
                "Explain why you accepted, edited, "
                "or rejected the AI diagnosis."
            )
        )

        final_diagnosis = st.text_input(
            "Final diagnosis",
            value=r["root_cause"]
        )

        # -----------------------------
        # Save Review
        # -----------------------------
        if st.button("Save Review"):

            new_review = pd.DataFrame([{
                "case_id": selected,
                "review_status": status,
                "reviewer_note": reviewer_note,
                "final_diagnosis": final_diagnosis
            }])

            new_review.to_csv(
                "review_log.csv",
                mode="a",
                header=False,
                index=False
            )

            # Update displayed review data
            reviews = pd.concat(
                [reviews, new_review],
                ignore_index=True
            )

            st.session_state["review_saved"] = True

            st.success(
                f"Review saved as: {status}"
            )

            st.info(
                "The review has been added to review_log.csv."
            )


# =================================
# Dashboard
# =================================

with tab2:

    st.subheader("Project Dashboard")

    a, b, c, d = st.columns(4)

    a.metric(
        "Total Cases",
        len(cases)
    )

    b.metric(
        "High/Critical",
        int(
            (
                cases.severity.isin(
                    ["High", "Critical"]
                )
            ).sum()
        )
    )

    c.metric(
        "Review Records",
        len(reviews)
    )

    if len(reviews) > 0:
        accepted = (reviews["review_status"] == "Accepted").sum()
        agreement = round((accepted / len(reviews)) * 100)
    else:
        agreement = 0

    d.metric(
        "AI/Human Agreement",
        f"{agreement}%"
    )
    st.caption(
        "*Sample project review-log metric; replace with measured "
        "results after the team completes all reviews."
    )

    fig, ax = plt.subplots()

    cases["concept"].value_counts().plot(
        kind="bar",
        ax=ax
    )

    ax.set_title("Cases by Issue Type")
    ax.set_xlabel("Concept")
    ax.set_ylabel("Number of Cases")

    st.pyplot(fig)

    fig2, ax2 = plt.subplots()

    cases["severity"].value_counts().plot(
        kind="bar",
        ax=ax2
    )

    ax2.set_title("Cases by Severity")
    ax2.set_xlabel("Severity")
    ax2.set_ylabel("Number of Cases")

    st.pyplot(fig2)


# =================================
# Responsible AI
# =================================

with tab3:

    st.subheader("Responsible AI Log")

    st.write(
        "The assignment requires documenting at least five "
        "cases where AI needed correction."
    )

    st.dataframe(
        reviews,
        use_container_width=True
    )