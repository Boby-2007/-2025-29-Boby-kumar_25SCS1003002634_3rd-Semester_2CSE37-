import json


def build_prompt(symptom, evidence):
    return f"""
You are NetSage AI, a Cisco/Packet Tracer troubleshooting assistant.

Use ONLY the supplied symptom and evidence.
Do not invent command output.

Return valid JSON with exactly these fields:
root_cause, confidence, osi_layer, evidence, next_command, fix_steps.

Symptom:
{symptom}

Show-command / topology evidence:
{evidence}
"""


def local_diagnosis(symptom, evidence):
    """Offline fallback for demos; deterministic and safe."""

    text = (symptom + " " + evidence).lower()

    root = "Insufficient evidence"
    layer = "Unknown"
    confidence = "Low"
    next_cmd = "Collect relevant show-command output"
    fix = ["Verify the configuration before changing it."]

    # Missing inter-VLAN route
    if (
        "no 192.168.40.0/24" in text
        or "no route" in text
        or "missing route" in text
        or "missing inter-vlan route" in text
    ):
        root = "Missing inter-VLAN route"
        layer = "Layer 3"
        confidence = "High"
        next_cmd = "show ip route"
        fix = [
            "Verify the destination network 192.168.40.0/24.",
            "Add or correct the required inter-VLAN route.",
            "Verify connectivity between VLAN 30 and VLAN 40."
        ]

    # Interface shutdown
    elif (
        "administratively down" in text
        or "shutdown" in text
    ):
        root = "Interface is administratively down"
        layer = "Layer 1/3"
        confidence = "High"
        next_cmd = "show ip interface brief"
        fix = [
            "Enter the affected interface.",
            "Use no shutdown.",
            "Verify interface status."
        ]

    # DHCP failure
    elif (
        "169.254." in text
        or ("dhcp" in text and "empty" in text)
    ):
        root = "DHCP failure"
        layer = "Layer 3"
        confidence = "High"
        next_cmd = "show ip dhcp binding"
        fix = [
            "Verify the DHCP pool.",
            "Verify VLAN/SVI connectivity.",
            "Verify ip helper-address when DHCP is remote."
        ]

    # ACL
    elif (
        "deny tcp" in text
        or "deny ip" in text
    ):
        root = "ACL is blocking traffic"
        layer = "Layer 4"
        confidence = "High"
        next_cmd = "show access-lists"
        fix = [
            "Inspect ACL sequence and counters.",
            "Correct the blocking rule if authorized.",
            "Retest connectivity."
        ]

    # NAT
    elif "nat translations empty" in text:
        root = "NAT is not creating translations"
        layer = "Layer 3"
        confidence = "High"
        next_cmd = "show ip nat translations"
        fix = [
            "Verify inside/outside interfaces.",
            "Verify NAT ACL matches the source subnet.",
            "Retest connectivity."
        ]

    # Trunk
    elif (
        "not allowed" in text
        or ("trunk" in text and "does not list" in text)
    ):
        root = "VLAN is missing from the trunk"
        layer = "Layer 2"
        confidence = "High"
        next_cmd = "show interfaces trunk"
        fix = [
            "Verify the trunk.",
            "Allow the required VLAN.",
            "Verify VLAN is active on both switches."
        ]

    return {
        "root_cause": root,
        "confidence": confidence,
        "osi_layer": layer,
        "evidence": evidence,
        "next_command": next_cmd,
        "fix_steps": fix
    }
