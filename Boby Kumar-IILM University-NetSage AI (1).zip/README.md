# NetSage AI – Applied AI + Network Troubleshooting

## Purpose
NetSage AI helps junior network engineers connect a network symptom with evidence from Cisco Packet Tracer/lab show commands. It provides a likely fault, OSI layer, confidence, evidence, next command, and fix steps. A human reviewer must approve or correct every diagnosis.

## Run
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Files
- `data/cases.csv` – 30 troubleshooting cases
- `rule_checker.py` – deterministic checks
- `ai_diagnosis.py` – prompt builder and offline diagnosis fallback
- `diagnose_prompt.md` – structured AI prompt
- `review_log.csv` – human oversight / responsible AI log
- `app.py` – dashboard and interactive demo

## Demo flow
1. Select a case.
2. Inspect symptom and evidence.
3. Run deterministic checks.
4. Run NetSage diagnosis.
5. Review the diagnosis.
6. Mark Accepted, Edited, or Rejected.
7. Inspect dashboard metrics.

## Human review
The application does not automatically apply Cisco configuration changes. Reviewers must decide whether the diagnosis is correct before any manual fix is performed.
